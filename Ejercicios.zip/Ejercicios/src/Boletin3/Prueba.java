package Boletin3;

public class Prueba {
    public static void main(String[] args) {
        saluda(" JUAN");
    }

    public static void saluda(String nombre) {
        System.out.println("HOLA" + nombre);

    }
}
