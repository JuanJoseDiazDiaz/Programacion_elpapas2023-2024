package ExamenColecciones2024.excepciones;

public class CategoriasProductosException extends Exception{
    public CategoriasProductosException(String message) {
        super(message);
    }
}
