package ExamenColecciones2024.excepciones;

public class TiendaException extends Exception{
    public TiendaException(String message) {
        super(message);
    }
}
